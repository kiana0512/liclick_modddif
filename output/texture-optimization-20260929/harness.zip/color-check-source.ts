import * as THREE from 'three';
import { renderSceneToPngUrl, applyTargetOnlyMaterial, isCaptureTargetMesh } from '/src/engine/capture/renderTargetUtils.ts';
import { renderSceneToPngUrl as renderBefore } from './render-before';
import { createClayModelMaterial } from '/src/engine/materials/clayModelMaterial.ts';
import { waitForBrowserPaint as waitForViewportFrame } from '/src/utils/browserScheduling.ts';
const waitForResidentUvPresentation=async()=>{};
export function colorsOld(){const renderSceneToPngUrl=renderBefore;async function captureClayTarget(
  passRequest: CapturePassRequest,
  encodedSize?: { width: number; height: number },
) {
  const captureMaterial = createClayModelMaterial();
  try {
    return {
      url: await renderSceneToPngUrl(
        {
          ...passRequest,
          clearColor: '#f7f7f3',
          clearAlpha: 1,
        },
        {
          applyDisplayTransform: true,
          // Keep the exact 2K ModelView input, but submit it in bounded GPU
          // tiles so the visible viewport receives a frame between capture
          // chunks. Total capture work stays equivalent without a multi-second
          // main-thread/GPU presentation stall on button 2.
          tileSize: 512,
          performancePhasePrefix: 'button2-white-model',
          encodedWidth: encodedSize?.width,
          encodedHeight: encodedSize?.height,
          // Restrict the scene only for the exact offscreen draw. Restoring
          // before every inter-tile browser frame keeps the live background,
          // grid and helpers continuously visible during snapshot preparation.
          prepareScene: () =>
            applyTargetOnlyMaterial(passRequest.scene, passRequest.objectId, () => captureMaterial),
        },
      ),
      warnings: [],
    };
  } finally {
    captureMaterial.dispose();
  }
}
function createFlatTargetCaptureMaterial(sourceMaterial: THREE.Material) {
  if (
    sourceMaterial instanceof THREE.ShaderMaterial &&
    sourceMaterial.uniforms.previewLightingEnabled
  ) {
    const material = sourceMaterial.clone();
    material.name = `${sourceMaterial.name || sourceMaterial.type}:FlatCapture`;
    material.uniforms.previewLightingEnabled.value = 0;
    // No renderer exposure is applied to this asset capture. Neutralize the
    // legacy rendered-colour compensation too, otherwise a user's PBR exposure
    // setting would still darken/brighten the supposedly flat reference.
    if (material.uniforms.previewExposure) material.uniforms.previewExposure.value = 1;
    if (material.uniforms.normalPreviewEnabled) material.uniforms.normalPreviewEnabled.value = 0;
    if (material.uniforms.wirePreviewEnabled) material.uniforms.wirePreviewEnabled.value = 0;
    // Capture albedo, not the viewport presentation. The returned image will be
    // sampled as an sRGB BaseColor and receive the viewport transform once.
    material.toneMapped = false;
    material.uniformsNeedUpdate = true;
    material.needsUpdate = true;
    return material;
  }

  const source = sourceMaterial as THREE.Material & {
    color?: THREE.Color;
    map?: THREE.Texture | null;
    alphaMap?: THREE.Texture | null;
    vertexColors?: boolean;
  };
  const material = new THREE.MeshBasicMaterial({
    color: source.color?.clone() ?? new THREE.Color('#ffffff'),
    map: source.map ?? null,
    alphaMap: source.alphaMap ?? null,
    transparent: sourceMaterial.transparent,
    opacity: sourceMaterial.opacity,
    alphaTest: sourceMaterial.alphaTest,
    side: sourceMaterial.side,
    depthTest: sourceMaterial.depthTest,
    depthWrite: sourceMaterial.depthWrite,
    vertexColors: source.vertexColors ?? false,
  });
  material.name = `${sourceMaterial.name || sourceMaterial.type}:FlatCapture`;
  material.blending = sourceMaterial.blending;
  material.blendSrc = sourceMaterial.blendSrc;
  material.blendDst = sourceMaterial.blendDst;
  material.blendEquation = sourceMaterial.blendEquation;
  material.premultipliedAlpha = sourceMaterial.premultipliedAlpha;
  material.polygonOffset = sourceMaterial.polygonOffset;
  material.polygonOffsetFactor = sourceMaterial.polygonOffsetFactor;
  material.polygonOffsetUnits = sourceMaterial.polygonOffsetUnits;
  material.toneMapped = false;
  return material;
}
function prepareFlatTargetCapture(
  passRequest: CapturePassRequest,
  options: { forceEmptyProjectionHatch?: boolean } = {},
) {
  const temporaryMaterials = new Set<THREE.Material>();
  const mutatedShaderMaterials = new Set<THREE.ShaderMaterial>();
  const restoreUniforms: Array<() => void> = [];
  const restoreScene = applyTargetOnlyMaterial(
    passRequest.scene,
    passRequest.objectId,
    (source) => {
      // The authored projection/UV material is already resident and compiled in
      // the viewport. Cloning it here creates a brand-new shader program and can
      // block Chromium's main/GPU threads for several seconds on button 2. Flat
      // capture only changes presentation uniforms, so borrow the resident
      // program for this single submitted draw and restore its values immediately
      // afterwards. Camera and model matrices remain the frozen click snapshot.
      if (source instanceof THREE.ShaderMaterial && source.uniforms.previewLightingEnabled) {
        if (!mutatedShaderMaterials.has(source)) {
          mutatedShaderMaterials.add(source);
          const previousValues = new Map<string, unknown>();
          const uniformOverrides: Array<readonly [string, number]> = [
            ['previewLightingEnabled', 0],
            ['previewExposure', 1],
            ['normalPreviewEnabled', 0],
            ['wirePreviewEnabled', 0],
          ];
          // Hatch is viewport-only. Mode 2 also writes true coverage into alpha.
          uniformOverrides.push(['showEmptyProjectionHatch', options.forceEmptyProjectionHatch ? 2 : 0]);
          for (const [name, value] of uniformOverrides) {
            const uniform = source.uniforms[name];
            if (!uniform) continue;
            previousValues.set(name, uniform.value);
            uniform.value = value;
          }
          source.uniformsNeedUpdate = true;
          restoreUniforms.push(() => {
            previousValues.forEach((value, name) => {
              const uniform = source.uniforms[name];
              if (uniform) uniform.value = value;
            });
            source.uniformsNeedUpdate = true;
          });
        }
        return source;
      }
      const material = createFlatTargetCaptureMaterial(source);
      // Coverage capture must distinguish an untextured material from a valid
      // white texture. Write zero coverage, but keep depth/occlusion intact.
      if (options.forceEmptyProjectionHatch && material instanceof THREE.MeshBasicMaterial &&
          !material.map && !material.vertexColors) {
        material.opacity = 0;
        material.transparent = false;
        material.blending = THREE.NoBlending;
        material.alphaTest = 0;
      }
      temporaryMaterials.add(material);
      return material;
    },
  );
  let restored = false;
  return () => {
    if (restored) return;
    restored = true;
    restoreScene();
    restoreUniforms.forEach((restoreUniform) => restoreUniform());
    temporaryMaterials.forEach((material) => material.dispose());
  };
}
async function captureFlatTarget(
  passRequest: CapturePassRequest,
  encodedSize?: { width: number; height: number },
  options: { forceEmptyProjectionHatch?: boolean } = {},
) {
  await waitForResidentUvPresentation(passRequest.scene, passRequest.objectId);
  // CAPTURE-MATERIAL-ISOLATION v1.0.0: never retain presentation mutations
  // across a browser-paint yield. Reject an interrupted snapshot rather than
  // encode tiles from different material generations into one GPT guide.
  const sourceMaterials = new Map<THREE.Mesh, THREE.Material[]>();
  const sourceUvMaps = new Map<THREE.Material, unknown[]>();
  passRequest.scene.traverse((object) => {
    if (object instanceof THREE.Mesh && object.userData.liclickObjectId === passRequest.objectId) {
      sourceMaterials.set(
        object,
        Array.isArray(object.material) ? [...object.material] : [object.material],
      );
      for (const material of sourceMaterials.get(object)!) {
        if (material instanceof THREE.ShaderMaterial && material.userData.liclickResidentUvProjectionLayers)
          sourceUvMaps.set(material, ['baseMap', 'uvOverlayMap', 'liveUvOverlayMap'].map(name => material.uniforms[name]?.value));
      }
    }
  });
  const prepareScene = () => {
    for (const [mesh, expected] of sourceMaterials) {
      const current = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
      if (
        current.length !== expected.length ||
        current.some((material, index) => material !== expected[index])
      ) {
        throw new Error('模型材质在截图期间发生变化，请等待预览稳定后重试。');
      }
      for (const material of current) {
        if (sourceUvMaps.has(material) && material instanceof THREE.ShaderMaterial &&
            sourceUvMaps.get(material)!.some((texture, index) =>
              texture !== material.uniforms[['baseMap', 'uvOverlayMap', 'liveUvOverlayMap'][index]]?.value))
          throw new Error('UV 预览在截图期间发生变化，请重试。');
      }
    }
    return prepareFlatTargetCapture(passRequest, options);
  };
  return {
    url: await renderSceneToPngUrl(
      {
        ...passRequest,
        clearColor: '#eeeeec',
        clearAlpha: 1,
      },
      // The render target's sRGB encoding is the texture asset encoding. Do
      // not bake exposure/tone mapping here: the preview shader applies that
      // presentation transform after the generated image is painted back.
      {
        applyDisplayTransform: false,
        tileSize: 512,
        performancePhasePrefix: 'button2-viewport-reference',
        encodedWidth: encodedSize?.width,
        encodedHeight: encodedSize?.height,
        prepareScene,
      },
    ),
    warnings: [],
  };
};return {clay:captureClayTarget,flat:captureFlatTarget};}
export function colorsNew(){async function captureClayTarget(
  passRequest: CapturePassRequest,
  encodedSize?: { width: number; height: number },
) {
  await waitForViewportFrame();
  const captureMaterial = createClayModelMaterial();
  try {
    return {
      url: await renderSceneToPngUrl(
        {
          ...passRequest,
          clearColor: '#f7f7f3',
          clearAlpha: 1,
        },
        {
          applyDisplayTransform: true,
          performancePhasePrefix: 'button2-white-model',
          encodedWidth: encodedSize?.width,
          encodedHeight: encodedSize?.height,
          // Restore the scene immediately after submission, before striped readback.
          prepareScene: () =>
            applyTargetOnlyMaterial(passRequest.scene, passRequest.objectId, () => captureMaterial),
        },
      ),
      warnings: [],
    };
  } finally {
    captureMaterial.dispose();
  }
}
function createFlatTargetCaptureMaterial(sourceMaterial: THREE.Material) {
  if (
    sourceMaterial instanceof THREE.ShaderMaterial &&
    sourceMaterial.uniforms.previewLightingEnabled
  ) {
    const material = sourceMaterial.clone();
    material.name = `${sourceMaterial.name || sourceMaterial.type}:FlatCapture`;
    material.uniforms.previewLightingEnabled.value = 0;
    // No renderer exposure is applied to this asset capture. Neutralize the
    // legacy rendered-colour compensation too, otherwise a user's PBR exposure
    // setting would still darken/brighten the supposedly flat reference.
    if (material.uniforms.previewExposure) material.uniforms.previewExposure.value = 1;
    if (material.uniforms.normalPreviewEnabled) material.uniforms.normalPreviewEnabled.value = 0;
    if (material.uniforms.wirePreviewEnabled) material.uniforms.wirePreviewEnabled.value = 0;
    // Capture albedo, not the viewport presentation. The returned image will be
    // sampled as an sRGB BaseColor and receive the viewport transform once.
    material.toneMapped = false;
    material.uniformsNeedUpdate = true;
    material.needsUpdate = true;
    return material;
  }

  const source = sourceMaterial as THREE.Material & {
    color?: THREE.Color;
    map?: THREE.Texture | null;
    alphaMap?: THREE.Texture | null;
    vertexColors?: boolean;
  };
  const material = new THREE.MeshBasicMaterial({
    color: source.color?.clone() ?? new THREE.Color('#ffffff'),
    map: source.map ?? null,
    alphaMap: source.alphaMap ?? null,
    transparent: sourceMaterial.transparent,
    opacity: sourceMaterial.opacity,
    alphaTest: sourceMaterial.alphaTest,
    side: sourceMaterial.side,
    depthTest: sourceMaterial.depthTest,
    depthWrite: sourceMaterial.depthWrite,
    vertexColors: source.vertexColors ?? false,
  });
  material.name = `${sourceMaterial.name || sourceMaterial.type}:FlatCapture`;
  material.blending = sourceMaterial.blending;
  material.blendSrc = sourceMaterial.blendSrc;
  material.blendDst = sourceMaterial.blendDst;
  material.blendEquation = sourceMaterial.blendEquation;
  material.premultipliedAlpha = sourceMaterial.premultipliedAlpha;
  material.polygonOffset = sourceMaterial.polygonOffset;
  material.polygonOffsetFactor = sourceMaterial.polygonOffsetFactor;
  material.polygonOffsetUnits = sourceMaterial.polygonOffsetUnits;
  material.toneMapped = false;
  return material;
}
function prepareFlatTargetCapture(
  passRequest: CapturePassRequest,
  options: { forceEmptyProjectionHatch?: boolean } = {},
) {
  const temporaryMaterials = new Set<THREE.Material>();
  const mutatedShaderMaterials = new Set<THREE.ShaderMaterial>();
  const restoreUniforms: Array<() => void> = [];
  const restoreScene = applyTargetOnlyMaterial(
    passRequest.scene,
    passRequest.objectId,
    (source) => {
      // The authored projection/UV material is already resident and compiled in
      // the viewport. Cloning it here creates a brand-new shader program and can
      // block Chromium's main/GPU threads for several seconds on button 2. Flat
      // capture only changes presentation uniforms, so borrow the resident
      // program for this single submitted draw and restore its values immediately
      // afterwards. Camera and model matrices remain the frozen click snapshot.
      if (source instanceof THREE.ShaderMaterial && source.uniforms.previewLightingEnabled) {
        if (!mutatedShaderMaterials.has(source)) {
          mutatedShaderMaterials.add(source);
          const previousValues = new Map<string, unknown>();
          const uniformOverrides: Array<readonly [string, number]> = [
            ['previewLightingEnabled', 0],
            ['previewExposure', 1],
            ['normalPreviewEnabled', 0],
            ['wirePreviewEnabled', 0],
          ];
          // Hatch is viewport-only. Mode 2 also writes true coverage into alpha.
          uniformOverrides.push(['showEmptyProjectionHatch', options.forceEmptyProjectionHatch ? 2 : 0]);
          for (const [name, value] of uniformOverrides) {
            const uniform = source.uniforms[name];
            if (!uniform) continue;
            previousValues.set(name, uniform.value);
            uniform.value = value;
          }
          source.uniformsNeedUpdate = true;
          restoreUniforms.push(() => {
            previousValues.forEach((value, name) => {
              const uniform = source.uniforms[name];
              if (uniform) uniform.value = value;
            });
            source.uniformsNeedUpdate = true;
          });
        }
        return source;
      }
      const material = createFlatTargetCaptureMaterial(source);
      // Coverage capture must distinguish an untextured material from a valid
      // white texture. Write zero coverage, but keep depth/occlusion intact.
      if (options.forceEmptyProjectionHatch && material instanceof THREE.MeshBasicMaterial &&
          !material.map && !material.vertexColors) {
        material.opacity = 0;
        material.transparent = false;
        material.blending = THREE.NoBlending;
        material.alphaTest = 0;
      }
      temporaryMaterials.add(material);
      return material;
    },
  );
  let restored = false;
  return () => {
    if (restored) return;
    restored = true;
    restoreScene();
    restoreUniforms.forEach((restoreUniform) => restoreUniform());
    temporaryMaterials.forEach((material) => material.dispose());
  };
}
async function captureFlatTarget(
  passRequest: CapturePassRequest,
  encodedSize?: { width: number; height: number },
  options: { forceEmptyProjectionHatch?: boolean } = {},
) {
  await waitForResidentUvPresentation(passRequest.scene, passRequest.objectId);
  await waitForViewportFrame();
  // CAPTURE-MATERIAL-ISOLATION v1.0.0: never retain presentation mutations
  // across a browser-paint yield. Reject an interrupted snapshot rather than
  // encode tiles from different material generations into one GPT guide.
  const sourceMaterials = new Map<THREE.Mesh, THREE.Material[]>();
  const sourceUvMaps = new Map<THREE.Material, unknown[]>();
  passRequest.scene.traverse((object) => {
    if (object instanceof THREE.Mesh && object.userData.liclickObjectId === passRequest.objectId) {
      sourceMaterials.set(
        object,
        Array.isArray(object.material) ? [...object.material] : [object.material],
      );
      for (const material of sourceMaterials.get(object)!) {
        if (material instanceof THREE.ShaderMaterial && material.userData.liclickResidentUvProjectionLayers)
          sourceUvMaps.set(material, ['baseMap', 'uvOverlayMap', 'liveUvOverlayMap'].map(name => material.uniforms[name]?.value));
      }
    }
  });
  const prepareScene = () => {
    for (const [mesh, expected] of sourceMaterials) {
      const current = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
      if (
        current.length !== expected.length ||
        current.some((material, index) => material !== expected[index])
      ) {
        throw new Error('模型材质在截图期间发生变化，请等待预览稳定后重试。');
      }
      for (const material of current) {
        if (sourceUvMaps.has(material) && material instanceof THREE.ShaderMaterial &&
            sourceUvMaps.get(material)!.some((texture, index) =>
              texture !== material.uniforms[['baseMap', 'uvOverlayMap', 'liveUvOverlayMap'][index]]?.value))
          throw new Error('UV 预览在截图期间发生变化，请重试。');
      }
    }
    return prepareFlatTargetCapture(passRequest, options);
  };
  return {
    url: await renderSceneToPngUrl(
      {
        ...passRequest,
        clearColor: '#eeeeec',
        clearAlpha: 1,
      },
      // The render target's sRGB encoding is the texture asset encoding. Do
      // not bake exposure/tone mapping here: the preview shader applies that
      // presentation transform after the generated image is painted back.
      {
        applyDisplayTransform: false,
        performancePhasePrefix: 'button2-viewport-reference',
        encodedWidth: encodedSize?.width,
        encodedHeight: encodedSize?.height,
        prepareScene,
      },
    ),
    warnings: [],
  };
};return {clay:captureClayTarget,flat:captureFlatTarget};}
