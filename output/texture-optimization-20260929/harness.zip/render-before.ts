import * as THREE from 'three';
import { waitForBrowserPaint } from '@/utils/browserScheduling';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import type { CapturePassRequest, SceneMaterialSnapshot } from './captureTypes';
import { createRegisteredObjectUrl } from '@/utils/blobUrlRegistry';
import { encodeFlippedGpuReadbackPngInWorker } from './png-before-client';
import { readRenderTargetPixelsInStripes } from './readback-before';

type RenderSceneToPngOptions = {
  applyDisplayTransform?: boolean;
  dataTexture?: boolean;
  samples?: number;
  ignoreSceneBackground?: boolean;
  /** Split the exact target into scissored GPU jobs so the visible renderer
   * can present between expensive depth/normal fragments. */
  tileSize?: number;
  waitForViewportIdle?: () => Promise<void>;
  performancePhasePrefix?: string;
  /** Encode to this size in the PNG worker after the GPU readback. This keeps
   * expensive interactive captures small without changing the service input
   * contract or doing image resampling on the main thread. */
  encodedWidth?: number;
  encodedHeight?: number;
  /** Encode an opaque scalar mask as PNG colour type 0. Decoded browser pixels
   * remain R=G=B and A=255 while transport work is reduced fourfold. */
  grayscaleOutput?: boolean;
  /**
   * Applies capture-only scene state immediately before each submitted draw
   * and restores it synchronously afterwards. Tiled captures must use this
   * instead of holding visibility/material mutations across browser frames,
   * otherwise the live viewport can present a hidden grid/background.
   */
  prepareScene?: () => () => void;
  /**
   * Runs as soon as the offscreen render and readback have been submitted,
   * before this function yields while waiting for the pixels. Callers that
   * temporarily mutate the live scene can restore it here so the viewport
   * never presents the capture-only materials or visibility state.
   */
  onRenderSubmitted?: () => void;
};

function markCapturePerformancePhase(prefix: string | undefined, suffix: string) {
  if (!prefix || typeof document === 'undefined') return;
  if (
    !prefix.startsWith('button2-') &&
    document.body.dataset.perfSimulatedViewportInteraction !== '1' &&
    document.body.dataset.perfContentAwareRepairMeasuring !== '1' &&
    document.body.dataset.perfUvMergeMeasuring !== '1'
  ) {
    return;
  }
  document.body.dataset.perfUvBakePhase = `${prefix}-${suffix}`;
  if (prefix.startsWith('button2-')) {
    document.body.dataset.perfLocalRepaintPhase = `${prefix}-${suffix}`;
  }
}

type RenderScenePass = {
  /**
   * Applies the material/visibility state for one accumulation pass and returns
   * a restorer. The restorer runs immediately after renderer submission.
   */
  prepare: () => () => void;
};

let displayOutputPass: OutputPass | undefined;
const INTERACTIVE_CAPTURE_GPU_BUDGET_MS = 4;

type SharedRendererState = {
  target: THREE.WebGLRenderTarget | null;
  clearColor: THREE.Color;
  clearAlpha: number;
  viewport: THREE.Vector4;
  scissor: THREE.Vector4;
  scissorTest: boolean;
  autoClear: boolean;
  xrEnabled: boolean;
};

function captureSharedRendererState(gl: THREE.WebGLRenderer): SharedRendererState {
  return {
    target: gl.getRenderTarget(),
    clearColor: gl.getClearColor(new THREE.Color()),
    clearAlpha: gl.getClearAlpha(),
    viewport: gl.getViewport(new THREE.Vector4()),
    scissor: gl.getScissor(new THREE.Vector4()),
    scissorTest: gl.getScissorTest(),
    autoClear: gl.autoClear,
    xrEnabled: gl.xr.enabled,
  };
}

function restoreSharedRendererState(gl: THREE.WebGLRenderer, state: SharedRendererState) {
  gl.setRenderTarget(state.target);
  gl.setClearColor(state.clearColor, state.clearAlpha);
  gl.setViewport(state.viewport);
  gl.setScissor(state.scissor);
  gl.setScissorTest(state.scissorTest);
  gl.autoClear = state.autoClear;
  gl.xr.enabled = state.xrEnabled;
}

// ALG-CAP-006 v1.0.1: own state only during synchronous GPU submission.
// Resize/zoom and other viewport work may publish newer state at every await.
function preserveCaptureState(request: CapturePassRequest) {
  const rendererState = captureSharedRendererState(request.gl);
  const background = request.scene.background;
  let restored = false;
  return () => {
    if (restored) return;
    restored = true;
    request.scene.background = background;
    restoreSharedRendererState(request.gl, rendererState);
  };
}

async function waitForSubmittedGpuWork(renderer: THREE.WebGLRenderer) {
  const context = renderer.getContext();
  if (!(context instanceof WebGL2RenderingContext)) {
    context.flush();
    return;
  }
  const fence = context.fenceSync(context.SYNC_GPU_COMMANDS_COMPLETE, 0);
  context.flush();
  if (!fence) return;
  try {
    await new Promise<void>((resolve, reject) => {
      const probe = () => {
        const status = context.clientWaitSync(fence, 0, 0);
        if (status === context.WAIT_FAILED) {
          reject(new Error('Offscreen capture GPU fence failed.'));
          return;
        }
        if (status === context.TIMEOUT_EXPIRED) {
          window.setTimeout(probe, 4);
          return;
        }
        resolve();
      };
      window.setTimeout(probe, 0);
    });
  } finally {
    context.deleteSync(fence);
  }
}

function getDisplayOutputPass() {
  displayOutputPass ??= new OutputPass();
  return displayOutputPass;
}

export async function renderSceneToPngUrl(
  request: CapturePassRequest,
  options: RenderSceneToPngOptions = {},
) {
  // Three.js intentionally skips renderer tone mapping for ordinary render
  // targets. Color captures therefore need a linear intermediate followed by
  // the same display transform used by the on-screen viewport.
  markCapturePerformancePhase(options.performancePhasePrefix, 'target-setup');
  const sceneTarget = new THREE.WebGLRenderTarget(request.width, request.height, {
    samples: options.samples ?? (request.width > 1024 || request.height > 1024 ? 0 : 2),
    ...(options.applyDisplayTransform
      ? { type: THREE.HalfFloatType, colorSpace: THREE.LinearSRGBColorSpace }
      : { colorSpace: options.dataTexture ? THREE.NoColorSpace : THREE.SRGBColorSpace }),
  });
  const outputTarget = options.applyDisplayTransform
    ? new THREE.WebGLRenderTarget(request.width, request.height, {
        colorSpace: THREE.NoColorSpace,
      })
    : undefined;
  const readTarget = outputTarget ?? sceneTarget;
  let restoreState = preserveCaptureState(request);
  let pixels: Uint8Array<ArrayBuffer>;
  const bindCaptureTarget = () => {
    request.gl.setRenderTarget(sceneTarget);
    request.gl.setClearColor(request.clearColor ?? '#000000', request.clearAlpha ?? 1);
  };
  try {
    if (options.ignoreSceneBackground) request.scene.background = null;
    bindCaptureTarget();
    request.gl.setScissorTest(false);
    request.gl.clear();
    const tileSize = Math.max(
      1,
      Math.min(
        Math.floor(options.tileSize ?? Math.max(request.width, request.height)),
        Math.max(request.width, request.height),
      ),
    );
    const tiled = tileSize < request.width || tileSize < request.height;
    if (tiled) {
      // ALG-CAP-006 v1.0.0: the first idle wait yields to R3F too.
      // Never leave the capture framebuffer or background installed there.
      restoreState();
      let presentationBudgetStartedAt = performance.now();
      for (let y = 0; y < request.height; y += tileSize) {
        for (let x = 0; x < request.width; x += tileSize) {
          await options.waitForViewportIdle?.();
          restoreState = preserveCaptureState(request);
          markCapturePerformancePhase(options.performancePhasePrefix, 'render-tile');
          bindCaptureTarget();
          request.gl.setScissorTest(true);
          request.gl.setScissor(
            x,
            y,
            Math.min(tileSize, request.width - x),
            Math.min(tileSize, request.height - y),
          );
          if (options.ignoreSceneBackground) request.scene.background = null;
          const restorePreparedScene = options.prepareScene?.();
          try {
            if (import.meta.env.VITE_LICLICK_PIPELINE_TRACE_ENABLED === 'true' && getPipelineTrace()) traceCaptureRender(request.gl, request.scene, request.camera, request.traceContext);
            else request.gl.render(request.scene, request.camera);
          } finally {
            restorePreparedScene?.();
          }
          // Do not let a detached depth/normal capture queue outrun the physical
          // GPU. A flush only submits work; it does not prevent several 256px
          // tiles accumulating behind the onscreen renderer and stealing a later
          // presentation interval. The asynchronous fence drains this tile while
          // leaving the main thread and viewport fully responsive.
          const tileCompletion = waitForSubmittedGpuWork(request.gl);
          // The capture target retains every completed tile. Restore the live
          // renderer before yielding so React Three Fiber cannot inherit our
          // target/scissor state.
          restoreState();
          markCapturePerformancePhase(options.performancePhasePrefix, 'gpu-wait');
          const trace = import.meta.env.VITE_LICLICK_PIPELINE_TRACE_ENABLED === 'true' ? getPipelineTrace() : undefined;
          if (import.meta.env.VITE_LICLICK_PIPELINE_TRACE_ENABLED === 'true' && trace) await traceAsync(trace, 'gpu.fence.wait', () => tileCompletion, request.traceContext);
          else await tileCompletion;
          if (
            (x + tileSize < request.width || y + tileSize < request.height) &&
            performance.now() - presentationBudgetStartedAt >= INTERACTIVE_CAPTURE_GPU_BUDGET_MS
          ) {
            // Resume after every rAF callback (including R3F presentation) has
            // submitted for this frame. Resolving directly inside rAF resumes in
            // a microtask and can put the next detached capture tile in front of
            // the visible viewport. Fast tiles may share the same bounded 4ms
            // window; this removes dozens of empty 16.7ms waits without allowing
            // background capture to monopolize a presentation interval.
            await waitForBrowserPaint();
            presentationBudgetStartedAt = performance.now();
          }
        }
      }
      restoreState = preserveCaptureState(request);
      request.gl.setRenderTarget(sceneTarget);
      request.gl.setScissorTest(false);
    } else {
      const restorePreparedScene = options.prepareScene?.();
      try {
        if (import.meta.env.VITE_LICLICK_PIPELINE_TRACE_ENABLED === 'true' && getPipelineTrace()) traceCaptureRender(request.gl, request.scene, request.camera, request.traceContext);
        else request.gl.render(request.scene, request.camera);
      } finally {
        restorePreparedScene?.();
      }
    }

    if (outputTarget) {
      getDisplayOutputPass().render(request.gl, outputTarget, sceneTarget, 0, false);
    }

    markCapturePerformancePhase(options.performancePhasePrefix, 'readback-submit');
    const readbackPromise = readRenderTargetPixelsInStripes(
      request.gl,
      readTarget,
      request.width,
      request.height,
    );
    // The async PBO read owns the submitted frame. Restore the shared renderer
    // before waiting so React Three Fiber can keep drawing the viewport.
    restoreState();
    options.onRenderSubmitted?.();
    markCapturePerformancePhase(options.performancePhasePrefix, 'readback-wait');
    const trace = import.meta.env.VITE_LICLICK_PIPELINE_TRACE_ENABLED === 'true' ? getPipelineTrace() : undefined;
    pixels = await (import.meta.env.VITE_LICLICK_PIPELINE_TRACE_ENABLED === 'true' && trace ? traceAsync(trace, 'capture.readback', () => readbackPromise, request.traceContext) : readbackPromise);
  } finally {
    restoreState();
    sceneTarget.dispose();
    outputTarget?.dispose();
  }

  markCapturePerformancePhase(options.performancePhasePrefix, 'encode-worker');
  const encodeStartedAt = performance.now();
  const png = await (import.meta.env.VITE_LICLICK_PIPELINE_TRACE_ENABLED === 'true' && request.traceContext
    ? (...args: Parameters<typeof encodeFlippedGpuReadbackPngInWorker>) => { args[5] = request.traceContext; return encodeFlippedGpuReadbackPngInWorker(...args); }
    : encodeFlippedGpuReadbackPngInWorker)(
    pixels,
    request.width,
    request.height,
    options.encodedWidth && options.encodedHeight
      ? { width: options.encodedWidth, height: options.encodedHeight }
      : undefined,
    options.grayscaleOutput ? 'grayscale' : 'rgba',
  );
  if (
    options.performancePhasePrefix === 'button2-mask-capture' &&
    typeof document !== 'undefined'
  ) {
    document.body.dataset.localRepaintMaskCaptureEncodeMs = (
      performance.now() - encodeStartedAt
    ).toFixed(1);
    document.body.dataset.localRepaintMaskCapturePngBytes = String(png.byteLength);
    document.body.dataset.localRepaintMaskCapturePngFormat = options.grayscaleOutput
      ? 'grayscale'
      : 'rgba';
  }
  markCapturePerformancePhase(options.performancePhasePrefix, 'publish');
  return createRegisteredObjectUrl(new Blob([png], { type: 'image/png' }));
}

/**
 * Renders several material passes into one target and performs exactly one GPU
 * readback + PNG encode. This is used by the accumulated repaint selection:
 * reading/encoding every archived camera projection separately made button 2
 * scale linearly to multi-second stalls.
 */
export async function renderScenePassesToPngUrl(
  request: CapturePassRequest,
  passes: RenderScenePass[],
  options: Pick<
    RenderSceneToPngOptions,
    'dataTexture' | 'ignoreSceneBackground' | 'onRenderSubmitted' | 'waitForViewportIdle'
  > = {},
) {
  const target = new THREE.WebGLRenderTarget(request.width, request.height, {
    samples: 0,
    colorSpace: options.dataTexture ? THREE.NoColorSpace : THREE.SRGBColorSpace,
  });
  let restoreState = preserveCaptureState(request);
  let pixels: Uint8Array<ArrayBuffer>;
  try {
    if (options.ignoreSceneBackground) request.scene.background = null;
    request.gl.autoClear = false;
    request.gl.setRenderTarget(target);
    request.gl.setClearColor(request.clearColor ?? '#000000', request.clearAlpha ?? 1);
    request.gl.clear(true, true, true);
    restoreState();
    for (let index = 0; index < passes.length; index += 1) {
      await options.waitForViewportIdle?.();
      restoreState = preserveCaptureState(request);
      request.gl.setRenderTarget(target);
      request.gl.setClearColor(request.clearColor ?? '#000000', request.clearAlpha ?? 1);
      request.gl.setScissorTest(false);
      request.gl.autoClear = false;
      if (options.ignoreSceneBackground) request.scene.background = null;
      const restore = passes[index].prepare();
      try {
        if (import.meta.env.VITE_LICLICK_PIPELINE_TRACE_ENABLED === 'true' && getPipelineTrace()) traceCaptureRender(request.gl, request.scene, request.camera, request.traceContext);
        else request.gl.render(request.scene, request.camera);
      } finally {
        restore();
      }
      // A repaint mask may contain many archived projector strokes. Submitting
      // every pass in one uninterrupted loop made button 2 monopolise the GPU
      // and prevented Chromium from presenting (or even dispatching CDP) for
      // several seconds. Drain one projector at a time, restore the shared
      // renderer and let the visible R3F frame present before continuing.
      const passCompletion = waitForSubmittedGpuWork(request.gl);
      restoreState();
      await passCompletion;
      // Every pass uses the same viewer camera but a different projector. Keep
      // accumulated colour while allowing the next projection to rasterize the
      // same front-most surface again.
      if (index + 1 < passes.length) {
        await waitForBrowserPaint();
        restoreState = preserveCaptureState(request);
        request.gl.setRenderTarget(target);
        request.gl.setScissorTest(false);
        request.gl.autoClear = false;
        request.gl.clearDepth();
        restoreState();
      }
    }
    restoreState = preserveCaptureState(request);
    request.gl.setRenderTarget(target);
    request.gl.setScissorTest(false);
    request.gl.autoClear = false;
    const readbackPromise = readRenderTargetPixelsInStripes(
      request.gl,
      target,
      request.width,
      request.height,
    );
    restoreState();
    options.onRenderSubmitted?.();
    const trace = import.meta.env.VITE_LICLICK_PIPELINE_TRACE_ENABLED === 'true' ? getPipelineTrace() : undefined;
    pixels = await (import.meta.env.VITE_LICLICK_PIPELINE_TRACE_ENABLED === 'true' && trace ? traceAsync(trace, 'capture.readback', () => readbackPromise, request.traceContext) : readbackPromise);
  } finally {
    restoreState();
    target.dispose();
  }

  const png = await (import.meta.env.VITE_LICLICK_PIPELINE_TRACE_ENABLED === 'true' && request.traceContext
    ? (...args: Parameters<typeof encodeFlippedGpuReadbackPngInWorker>) => { args[5] = request.traceContext; return encodeFlippedGpuReadbackPngInWorker(...args); }
    : encodeFlippedGpuReadbackPngInWorker)(pixels, request.width, request.height);
  return createRegisteredObjectUrl(new Blob([png], { type: 'image/png' }));
}

/**
 * Copies the live viewport camera for an offscreen target without changing the
 * authored view. The vertical framing is preserved while the horizontal field
 * of view is recalculated for the target aspect ratio. Rendering a wide camera
 * directly into a square target would otherwise squeeze the model.
 */
export function cloneCameraForCaptureAspect(source: THREE.Camera, aspect: number) {
  const safeAspect = Number.isFinite(aspect) && aspect > 0 ? aspect : 1;
  const camera = source.clone();

  if (camera instanceof THREE.PerspectiveCamera) {
    camera.aspect = safeAspect;
    camera.updateProjectionMatrix();
  } else if (camera instanceof THREE.OrthographicCamera) {
    const centerX = (camera.left + camera.right) * 0.5;
    const halfHeight = Math.max((camera.top - camera.bottom) * 0.5, 0.0001);
    const halfWidth = halfHeight * safeAspect;
    camera.left = centerX - halfWidth;
    camera.right = centerX + halfWidth;
    camera.updateProjectionMatrix();
  }

  camera.updateMatrixWorld(true);
  return camera;
}

export function isCaptureTargetMesh(object: THREE.Object3D, objectId: string): object is THREE.Mesh {
  const data = object.userData;
  return object instanceof THREE.Mesh && data.liclickObjectId === objectId &&
    !data.liclickRestorePlaceholder && !data.liclickViewportHelper && !data.liclickPaintOverlay &&
    !data.liclickSelectionGlow && !data.liclickWireframeOverlay;
}

export function applyTargetOnlyMaterial(
  scene: THREE.Scene,
  objectId: string,
  materialFactory?: (sourceMaterial: THREE.Material) => THREE.Material,
) {
  const snapshots: SceneMaterialSnapshot[] = [];
  const targetMeshes = new Set<THREE.Mesh>();
  const targetAncestors = new Set<THREE.Object3D>([scene]);

  scene.traverse((object) => {
    if (!isCaptureTargetMesh(object, objectId)) return;
    targetMeshes.add(object);
    let parent: THREE.Object3D | null = object.parent;
    while (parent) {
      targetAncestors.add(parent);
      parent = parent.parent;
    }
  });

  scene.traverse((object) => {
    if (object === scene || object instanceof THREE.Camera || object instanceof THREE.Light) return;
    const isTarget = object instanceof THREE.Mesh && targetMeshes.has(object);
    const isTargetAncestor = targetAncestors.has(object);
    snapshots.push({
      object,
      visible: object.visible,
      material: object instanceof THREE.Mesh ? object.material : undefined,
    });
    object.visible = isTarget || isTargetAncestor;
    if (isTarget && materialFactory) {
      object.material = Array.isArray(object.material)
        ? object.material.map((material) => materialFactory(material))
        : materialFactory(object.material);
    }
  });

  let restored = false;
  return () => {
    // Submission restores before async readback/encoding. A later finally must
    // not replay this old snapshot over a newer selection or material commit.
    if (restored) return;
    restored = true;
    snapshots.forEach((snapshot) => {
      snapshot.object.visible = snapshot.visible;
      if (snapshot.object instanceof THREE.Mesh && snapshot.material) {
        snapshot.object.material = snapshot.material;
      }
    });
  };
}
import { getPipelineTrace, traceAsync } from '@/engine/performance/tracing/pipelineTrace';
import { traceCaptureRender } from '@/engine/performance/tracing/traceCapturePass';
