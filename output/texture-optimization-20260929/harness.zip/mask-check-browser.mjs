import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { makeCapture } from './mask-check-source.ts';
import { colorsOld, colorsNew } from './color-check-source.ts';
import { readRenderTargetPixelsInStripes as readback } from '/src/engine/bake/gpuReadbackStripes.ts';
import { revokeRegisteredObjectUrl } from '/src/utils/blobUrlRegistry.ts';
const out=document.querySelector('#result');
document.querySelector('#full').onclick=()=>document.documentElement.requestFullscreen();
const gl=new THREE.WebGLRenderer({antialias:true});gl.setPixelRatio(1);gl.setSize(innerWidth,innerHeight);document.body.append(gl.domElement);
const scene=new THREE.Scene();scene.background=new THREE.Color('#19232d');
const camera=new THREE.PerspectiveCamera(40,innerWidth/innerHeight,0.01,1000);
const loaded=await new GLTFLoader().loadAsync('/__bicycle.glb');
const model=loaded.scene;scene.add(model);model.updateMatrixWorld(true);
const box=new THREE.Box3().setFromObject(model),center=box.getCenter(new THREE.Vector3()),size=box.getSize(new THREE.Vector3());
model.position.sub(center);model.scale.setScalar(3/Math.max(size.x,size.y,size.z));model.updateMatrixWorld(true);
camera.position.set(3,1.5,5);camera.lookAt(0,0,0);
scene.add(new THREE.HemisphereLight(0xffffff,0x555555,3));
const maskBytes=new Uint8Array(64*64*4);for(let y=0;y<64;y++)for(let x=0;x<64;x++){const i=(y*64+x)*4;maskBytes[i]=x<32?255:0;maskBytes[i+1]=y<32?255:0;maskBytes[i+3]=255;}
const texture=new THREE.DataTexture(maskBytes,64,64);texture.needsUpdate=true;
const meshes=[];let triangles=0;model.traverse(o=>{if(o.isMesh){o.userData.liclickObjectId='bike';meshes.push(o);triangles+=(o.geometry.index?.count??o.geometry.attributes.position.count)/3;}});
const layer={objectId:'bike',accumulatedMaskReady:true,accumulatedMaskMeshes:new Set(meshes),accumulatedMaskTarget:{texture},maskInverted:false};
const scope={getTargetModel:()=>({objectId:'bike',group:model}),layerRef:{current:layer},isPerformanceInstrumentationEnabled:()=>false,maskHasContentRef:{current:true},currentProjectionHasContentRef:{current:false},currentProjectionOperationRef:{current:'add'},archiveCurrentInpaintProjection:()=>{throw Error('Unexpected archive');},gl,scene,camera};
const captures={old:makeCapture('old',scope),new:makeCapture('new',scope)};
const colors={old:colorsOld(),new:colorsNew()};
let active,frames=[],last=performance.now(),pointer=[],rotation=0;
addEventListener('pointermove',e=>{if(active){pointer.push(performance.now()-e.timeStamp);rotation=e.clientX/innerWidth*.2;}});
function draw(t){if(active)frames.push(t-last);last=t;camera.position.x=3+rotation;camera.lookAt(0,0,0);gl.render(scene,camera);requestAnimationFrame(draw);}requestAnimationFrame(draw);
addEventListener('resize',()=>{gl.setSize(innerWidth,innerHeight);camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();});
out.textContent=`就绪 · Bicycle ${triangles} triangles · 请先进入全屏`;
const percentile=(a,p)=>a.length?[...a].sort((a,b)=>a-b)[Math.min(a.length-1,Math.floor(a.length*p))]:null;
const readButton=document.createElement('button');readButton.textContent='读回调度对照';readButton.id='readback';document.querySelector('header').insertBefore(readButton,out);
const encodeButton=document.createElement('button');encodeButton.textContent='PNG 编码对照';encodeButton.id='encode';document.querySelector('header').insertBefore(encodeButton,out);
encodeButton.onclick=async()=>{
 const workers={old:new Worker(new URL('./png-before.worker.ts',import.meta.url),{type:'module'}),new:new Worker(new URL('../apps/web/src/workers/encodeGpuReadbackPng.worker.ts',import.meta.url),{type:'module'})};
 try{
  if(!document.fullscreenElement||document.visibilityState!=='visible')throw Error('必须全屏');
  const rows=[];
  for(const sourceName of ['flat','clay']){
   const source=await decode('/@fs/D:/li3d/output/texture-optimization-20260929/'+sourceName+'-old.png');let golden;
   for(const mode of ['new','old','old','new','new','old','old','new','new','old','old','new','new','old','old','new','new','old','old','new']){
    const bytes=source.pixels.slice().buffer;out.textContent=`PNG ${sourceName} / ${mode}`;frames=[];pointer=[];active=true;
    const start=performance.now();const png=await new Promise((resolve,reject)=>{const worker=workers[mode];worker.onmessage=e=>e.data.error?reject(Error(e.data.error)):resolve(e.data.png);worker.onerror=e=>reject(Error(e.message));worker.postMessage({id:1,pixels:bytes,width:source.width,height:source.height},[bytes]);});const ms=performance.now()-start;active=false;
    const data=new Uint8Array(png);if(!golden)golden=data;let differences=0;if(data.length!==golden.length)throw Error('PNG length changed');for(let i=0;i<data.length;i++)if(data[i]!==golden[i])differences++;
    rows.push({source:sourceName,mode,ms,bytes:data.length,differences,frameP95:percentile(frames,.95),pointerP95:percentile(pointer,.95)});if(differences)throw Error('PNG bytes changed');
   }
  }
  const report={viewport:[innerWidth,innerHeight],fullscreen:true,rows};await fetch('/__artifact/encode-results.json',{method:'POST',body:JSON.stringify(report,null,2)});out.textContent='PASS\n'+JSON.stringify(report,null,2);
 }catch(e){out.textContent='FAIL '+e.stack;}finally{active=false;Object.values(workers).forEach(w=>w.terminate());}
};
readButton.onclick=async()=>{
 try {
  if(!document.fullscreenElement||document.visibilityState!=='visible')throw Error('必须全屏');
  const rows=[];
  for(const [width,height] of [[2048,2048],[2048,1495],[4096,4096]]) {
   const target=new THREE.WebGLRenderTarget(width,height,{colorSpace:THREE.SRGBColorSpace});
   const frozen=camera.clone();frozen.aspect=width/height;frozen.updateProjectionMatrix();gl.setRenderTarget(target);gl.render(scene,frozen);gl.setRenderTarget(null);
   let golden;
   try {for(const mode of ['paint','task','task','paint','paint','task','task','paint']) {
    out.textContent=`读回 ${width}×${height} / ${mode}`;await new Promise(requestAnimationFrame);frames=[];pointer=[];active=true;
    const start=performance.now();const bytes=await readback(gl,target,width,height,mode);const ms=performance.now()-start;active=false;
    let differences=0;if(!golden)golden=bytes;for(let i=0;i<bytes.length;i++)if(bytes[i]!==golden[i])differences++;
    rows.push({width,height,mode,ms,differences,frameP95:percentile(frames,.95),frameMax:Math.max(...frames),pointerP95:percentile(pointer,.95),pointerCount:pointer.length});if(differences)throw Error('Readback pixels differ');
   }}finally{target.dispose();}
  }
  const report={viewport:[innerWidth,innerHeight],fullscreen:!!document.fullscreenElement,rows};
  await fetch('/__artifact/readback-results.json',{method:'POST',body:JSON.stringify(report,null,2)});out.textContent='PASS\n'+JSON.stringify(report,null,2);
 }catch(e){out.textContent='FAIL '+e.stack;}finally{active=false;}
};
async function decode(url){const b=await createImageBitmap(await(await fetch(url)).blob());const c=new OffscreenCanvas(b.width,b.height);const ctx=c.getContext('2d',{willReadFrequently:true});ctx.drawImage(b,0,0);b.close();return {width:c.width,height:c.height,pixels:ctx.getImageData(0,0,c.width,c.height).data};}
document.querySelector('#run').onclick=async()=>{
 try{
  if(!document.fullscreenElement||document.visibilityState!=='visible')throw Error('必须在可见全屏下运行');
  document.querySelector('#run').disabled=true;
  const viewport=[innerWidth,innerHeight],frozen=camera.clone();frozen.aspect=1;frozen.updateProjectionMatrix();
  const rows=[];let golden;const scenarios=[{name:'mask',aspect:1,invert:false},{name:'flat',aspect:1,invert:false},{name:'clay',aspect:1,invert:false}];
  for(const scenario of scenarios){layer.maskInverted=scenario.invert;golden=undefined;
   for(const mode of ['old','new','new','old','old','new','new','old']){
    if(document.visibilityState!=='visible'||!document.fullscreenElement||viewport[0]!==innerWidth||viewport[1]!==innerHeight)throw Error('显示状态变化，作废此次采样');
    out.textContent=`运行 ${scenario.name} / ${mode} · 可移动鼠标验证导航响应`;
    await new Promise(requestAnimationFrame);frames=[];pointer=[];active=true;
    const start=performance.now();const url=scenario.name==='mask'?await captures[mode]({resolution:2048,aspect:scenario.aspect,camera:frozen}):(await colors[mode][scenario.name]({gl,scene,camera:frozen,objectId:'bike',width:2048,height:2048},{width:2048,height:2048})).url;const ms=performance.now()-start;active=false;
    const timing={scenario:scenario.name,mode,ms,frameP95:percentile(frames,.95),frameMax:Math.max(...frames),pointerP95:percentile(pointer,.95),pointerCount:pointer.length};
    const image=await decode(url);if(!rows.some(r=>r.scenario===scenario.name&&r.mode===mode))await fetch('/__artifact/'+scenario.name+'-'+mode+'.png',{method:'POST',body:await(await fetch(url)).blob()});revokeRegisteredObjectUrl(url);let differences=0,nonzero=0;
    if(!golden)golden=image;
    if(image.width!==golden.width||image.height!==golden.height)throw Error('Dimensions differ');
    for(let i=0;i<image.pixels.length;i++){if(image.pixels[i]!==golden.pixels[i])differences++;if(i%4===0&&image.pixels[i])nonzero++;}
    rows.push({...timing,width:image.width,height:image.height,differences,nonzero});if(differences||!nonzero)throw Error('Pixel parity/nonempty failure');
   }
  }
  const report={viewport,triangles,fullscreen:true,rows,summary:scenarios.map(s=>({scenario:s.name,...Object.fromEntries(['old','new'].map(m=>[m,percentile(rows.filter(r=>r.scenario===s.name&&r.mode===m).slice(1).map(r=>r.ms),.5)]))}))};
  await fetch('/__evidence',{method:'POST',body:JSON.stringify(report,null,2)});await fetch('/__artifact/capture-results.json',{method:'POST',body:JSON.stringify(report,null,2)});out.textContent='PASS\n'+JSON.stringify(report,null,2);
 }catch(e){active=false;out.textContent='FAIL '+e.stack;}finally{document.querySelector('#run').disabled=false;}
};
