import * as THREE from 'three';
import { renderSceneToPngUrl, applyTargetOnlyMaterial, cloneCameraForCaptureAspect } from '/src/engine/capture/renderTargetUtils.ts';
import { renderSceneToPngUrl as renderBefore } from './render-before';
import { waitForBrowserPaint } from '/src/utils/browserScheduling.ts';
const PROJECTION_PAINT_MAX_SIZE = 512;
const INPAINT_DEPTH_EPSILON = 0.00002;
function bindInpaintDepthTarget(
  material: THREE.ShaderMaterial,
  target: THREE.WebGLRenderTarget | undefined,
  ready = Boolean(target),
) {
  // Keep HMR-compatible paint layers usable while their material instance is
  // replaced by the new depth-aware overlay generation.
  if (
    !material.uniforms.occlusionDepthMap ||
    !material.uniforms.occlusionDepthTexelSize ||
    !material.uniforms.occlusionDepthReady
  )
    return;
  material.uniforms.occlusionDepthMap.value = target?.depthTexture ?? null;
  (material.uniforms.occlusionDepthTexelSize.value as THREE.Vector2).set(
    target ? 1 / Math.max(1, target.width) : 1,
    target ? 1 / Math.max(1, target.height) : 1,
  );
  material.uniforms.occlusionDepthReady.value = ready && target?.depthTexture ? 1 : 0;
}
const inpaintDepthShader = `
  uniform sampler2D occlusionDepthMap;
  uniform vec2 occlusionDepthTexelSize;
  uniform float occlusionDepthReady;
  uniform float occlusionDepthEpsilon;

  bool isProjectorSurfaceVisible(vec2 projectorUv, float projectedDepth) {
    // A missing depth capture must never turn the screen-space projector into
    // an x-ray brush. Pointer input waits for this capture as well, while this
    // fail-closed branch protects the live preview and all later capture paths.
    if (occlusionDepthReady < 0.5) return false;
    float visibleDepth = texture2D(occlusionDepthMap, projectorUv).r;
    if (visibleDepth >= 0.999999) {
      // At a raster silhouette the centre texel can be clear even though the
      // brush still covers the edge. Fall back only to the nearest valid
      // neighbour. Using the farthest neighbour here admitted surfaces behind
      // thin shells and gaps.
      float nearestDepth = 1.0;
      float validSamples = 0.0;
      vec2 offsets[4];
      offsets[0] = vec2(occlusionDepthTexelSize.x, 0.0);
      offsets[1] = vec2(-occlusionDepthTexelSize.x, 0.0);
      offsets[2] = vec2(0.0, occlusionDepthTexelSize.y);
      offsets[3] = vec2(0.0, -occlusionDepthTexelSize.y);
      for (int index = 0; index < 4; index++) {
        float capturedDepth = texture2D(
          occlusionDepthMap,
          clamp(projectorUv + offsets[index], vec2(0.0), vec2(1.0))
        ).r;
        if (capturedDepth < 0.999999) {
          nearestDepth = min(nearestDepth, capturedDepth);
          validSamples += 1.0;
        }
      }
      if (validSamples < 0.5) return false;
      visibleDepth = nearestDepth;
    }
    return projectedDepth <= visibleDepth + occlusionDepthEpsilon;
  }
`;
function createInpaintMaskCaptureMaterial(
  maskTexture: THREE.Texture,
  depthTarget?: THREE.WebGLRenderTarget,
  maskUsesUv = false,
) {
  const material = new THREE.ShaderMaterial({
    uniforms: {
      maskMap: { value: maskTexture },
      occlusionDepthMap: { value: null },
      occlusionDepthTexelSize: { value: new THREE.Vector2(1, 1) },
      occlusionDepthReady: { value: 0 },
      occlusionDepthEpsilon: { value: INPAINT_DEPTH_EPSILON },
      projectorMatrix: { value: new THREE.Matrix4() },
      projectorPosition: { value: new THREE.Vector3() },
      projectionReady: { value: 1 },
      maskUsesUv: { value: maskUsesUv ? 1 : 0 },
      maskInverted: { value: 0 },
    },
    vertexShader: `
      uniform mat4 projectorMatrix;
      uniform vec3 projectorPosition;
      varying vec4 vProjectedPosition;
      varying float vProjectorFacing;
      varying float vViewerFacing;
      varying vec2 vSurfaceUv;

      void main() {
        vec4 worldPosition = modelMatrix * vec4(position, 1.0);
        vec3 worldNormal = normalize(mat3(modelMatrix) * normal);
        vec3 projectorDirection = normalize(projectorPosition - worldPosition.xyz);
        vec3 viewerDirection = normalize(cameraPosition - worldPosition.xyz);
        vProjectedPosition = projectorMatrix * worldPosition;
        vProjectorFacing = dot(worldNormal, projectorDirection);
        vViewerFacing = dot(worldNormal, viewerDirection);
        vSurfaceUv = uv;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: `
      uniform sampler2D maskMap;
      uniform float maskUsesUv;
      uniform float maskInverted;
      varying vec4 vProjectedPosition;
      varying float vProjectorFacing;
      varying float vViewerFacing;
      varying vec2 vSurfaceUv;
      ${inpaintDepthShader}

      void main() {
        vec2 maskUv;
        if (maskUsesUv > 0.5) {
          maskUv = vSurfaceUv;
        } else {
          if (
            vProjectedPosition.w <= 0.0001 ||
            vProjectorFacing * vViewerFacing < 0.0
          ) discard;
          vec3 ndc = vProjectedPosition.xyz / vProjectedPosition.w;
          if (abs(ndc.x) > 1.0 || abs(ndc.y) > 1.0 || abs(ndc.z) > 1.0) discard;
          vec2 projectorUv = ndc.xy * 0.5 + 0.5;
          if (!isProjectorSurfaceVisible(projectorUv, ndc.z * 0.5 + 0.5)) discard;
          maskUv = projectorUv;
          maskUv.y = 1.0 - maskUv.y;
        }
        vec4 maskTexel = texture2D(maskMap, maskUv);
        float coverage = maskUsesUv > 0.5
          ? (vViewerFacing >= 0.0 ? maskTexel.r : maskTexel.g)
          : max(maskTexel.r, max(maskTexel.g, maskTexel.b)) * maskTexel.a;
        if (maskInverted > 0.5) coverage = 1.0 - coverage;
        gl_FragColor = vec4(vec3(coverage > 0.01 ? coverage : 0.0), 1.0);
      }
    `,
    transparent: true,
    depthWrite: true,
    depthTest: true,
    side: THREE.DoubleSide,
    toneMapped: false,
  });
  bindInpaintDepthTarget(material, depthTarget);
  return material;
}
export function makeCapture(mode, scope) { const {getTargetModel,layerRef,isPerformanceInstrumentationEnabled,maskHasContentRef,currentProjectionHasContentRef,currentProjectionOperationRef,archiveCurrentInpaintProjection,gl,scene,camera}=scope; const captureRender=mode==='old'?renderBefore:renderSceneToPngUrl; return ((renderSceneToPngUrl)=>mode==='old' ? (async (options?: { aspect?: number; camera?: THREE.Camera; resolution?: number }) => {
      const model = getTargetModel();
      const layer = layerRef.current;
      if (isPerformanceInstrumentationEnabled()) {
        document.body.dataset.localRepaintButton2CapturePrerequisites = JSON.stringify({
          modelObjectId: model?.objectId ?? null,
          layerObjectId: layer?.objectId ?? null,
          sameObject: Boolean(model && layer && layer.objectId === model.objectId),
          maskHasContent: maskHasContentRef.current,
          currentProjectionHasContent: currentProjectionHasContentRef.current,
          accumulatedMaskReady: layer?.accumulatedMaskReady ?? false,
          maskDepthReady: layer?.maskDepthReady ?? false,
          hasMaskDepthTarget: Boolean(layer?.maskDepthTarget),
          accumulatedMeshCount: layer?.accumulatedMaskMeshes.size ?? 0,
          currentProjectionMeshCount: layer?.currentProjectionMeshes.size ?? 0,
        });
      }
      if (!model || !layer || layer.objectId !== model.objectId || !maskHasContentRef.current)
        return undefined;

      // Freeze the exact add/subtract selection shown by the overlay before
      // capture. The canonical accumulated UV mask is the only submitted source;
      // rendering projector snapshots again would union erased pixels back in.
      if (
        currentProjectionHasContentRef.current &&
        !archiveCurrentInpaintProjection(layer, model, currentProjectionOperationRef.current)
      ) {
        throw new Error('无法固定当前局部重绘蒙版，请稍后重试。');
      }
      if (!layer.accumulatedMaskReady && !layer.maskInverted) return undefined;

      const viewportRect = gl.domElement.getBoundingClientRect();
      const viewportAspect = viewportRect.width / Math.max(viewportRect.height, 1);
      const aspect =
        Number.isFinite(options?.aspect) && (options?.aspect ?? 0) > 0
          ? options!.aspect!
          : viewportAspect;
      const captureSize = Math.max(
        1,
        Math.min(2048, Math.round(options?.resolution ?? PROJECTION_PAINT_MAX_SIZE)),
      );
      const width = aspect >= 1 ? captureSize : Math.max(1, Math.round(captureSize * aspect));
      const height = aspect >= 1 ? Math.max(1, Math.round(captureSize / aspect)) : captureSize;
      const material = createInpaintMaskCaptureMaterial(
        layer.accumulatedMaskTarget.texture,
        undefined,
        true,
      );
      material.transparent = false;
      material.uniforms.maskInverted.value = layer.maskInverted ? 1 : 0;
      const capturedMeshes = layer.maskInverted ? undefined : new Set(layer.accumulatedMaskMeshes);
      const occluder = new THREE.MeshBasicMaterial({
        color: 0x000000, side: THREE.DoubleSide, toneMapped: false,
      });
      const startedAt = performance.now();
      try {
        const maskUrl = await renderSceneToPngUrl(
          {
            gl,
            scene,
            camera: cloneCameraForCaptureAspect(options?.camera ?? camera, aspect),
            objectId: model.objectId,
            width,
            height,
            clearColor: '#000000',
            clearAlpha: 1,
          },
          {
            dataTexture: true,
            grayscaleOutput: true,
            ignoreSceneBackground: true,
            tileSize: PROJECTION_PAINT_MAX_SIZE,
            performancePhasePrefix: 'button2-mask-capture',
            waitForViewportIdle: waitForBrowserPaint,
            prepareScene: () => {
              const restoreScene = applyTargetOnlyMaterial(scene, model.objectId, () => material);
              if (capturedMeshes) {
                scene.traverse((object) => {
                  if (!(object instanceof THREE.Mesh)) return;
                  if (object.userData.liclickObjectId !== model.objectId) return;
                  if (object.visible && !capturedMeshes.has(object)) object.material = occluder;
                });
              }
              return restoreScene;
            },
          },
        );
        document.body.dataset.localRepaintButton2MaskCaptureMs = (
          performance.now() - startedAt
        ).toFixed(1);
        document.body.dataset.localRepaintButton2MaskProjectionCount = '1';
        return maskUrl;
      } finally {
        material.dispose();
        occluder.dispose();
      }
    }) : (async (options?: { aspect?: number; camera?: THREE.Camera; resolution?: number }) => {
      const model = getTargetModel();
      const layer = layerRef.current;
      if (isPerformanceInstrumentationEnabled()) {
        document.body.dataset.localRepaintButton2CapturePrerequisites = JSON.stringify({
          modelObjectId: model?.objectId ?? null,
          layerObjectId: layer?.objectId ?? null,
          sameObject: Boolean(model && layer && layer.objectId === model.objectId),
          maskHasContent: maskHasContentRef.current,
          currentProjectionHasContent: currentProjectionHasContentRef.current,
          accumulatedMaskReady: layer?.accumulatedMaskReady ?? false,
          maskDepthReady: layer?.maskDepthReady ?? false,
          hasMaskDepthTarget: Boolean(layer?.maskDepthTarget),
          accumulatedMeshCount: layer?.accumulatedMaskMeshes.size ?? 0,
          currentProjectionMeshCount: layer?.currentProjectionMeshes.size ?? 0,
        });
      }
      if (!model || !layer || layer.objectId !== model.objectId || !maskHasContentRef.current)
        return undefined;

      // Freeze the exact add/subtract selection shown by the overlay before
      // capture. The canonical accumulated UV mask is the only submitted source;
      // rendering projector snapshots again would union erased pixels back in.
      if (
        currentProjectionHasContentRef.current &&
        !archiveCurrentInpaintProjection(layer, model, currentProjectionOperationRef.current)
      ) {
        throw new Error('无法固定当前局部重绘蒙版，请稍后重试。');
      }
      if (!layer.accumulatedMaskReady && !layer.maskInverted) return undefined;

      const viewportRect = gl.domElement.getBoundingClientRect();
      const viewportAspect = viewportRect.width / Math.max(viewportRect.height, 1);
      const aspect =
        Number.isFinite(options?.aspect) && (options?.aspect ?? 0) > 0
          ? options!.aspect!
          : viewportAspect;
      const captureSize = Math.max(
        1,
        Math.min(2048, Math.round(options?.resolution ?? PROJECTION_PAINT_MAX_SIZE)),
      );
      const width = aspect >= 1 ? captureSize : Math.max(1, Math.round(captureSize * aspect));
      const height = aspect >= 1 ? Math.max(1, Math.round(captureSize / aspect)) : captureSize;
      const material = createInpaintMaskCaptureMaterial(
        layer.accumulatedMaskTarget.texture,
        undefined,
        true,
      );
      material.transparent = false;
      material.uniforms.maskInverted.value = layer.maskInverted ? 1 : 0;
      const capturedMeshes = layer.maskInverted ? undefined : new Set(layer.accumulatedMaskMeshes);
      const occluder = new THREE.MeshBasicMaterial({
        color: 0x000000, side: THREE.DoubleSide, toneMapped: false,
      });
      const startedAt = performance.now();
      try {
        // Submit the frozen mask once; keep striped readback for viewport responsiveness.
        await waitForBrowserPaint();
        const maskUrl = await renderSceneToPngUrl(
          {
            gl,
            scene,
            camera: cloneCameraForCaptureAspect(options?.camera ?? camera, aspect),
            objectId: model.objectId,
            width,
            height,
            clearColor: '#000000',
            clearAlpha: 1,
          },
          {
            dataTexture: true,
            grayscaleOutput: true,
            ignoreSceneBackground: true,
            performancePhasePrefix: 'button2-mask-capture',
            prepareScene: () => {
              const restoreScene = applyTargetOnlyMaterial(scene, model.objectId, () => material);
              if (capturedMeshes) {
                scene.traverse((object) => {
                  if (!(object instanceof THREE.Mesh)) return;
                  if (object.userData.liclickObjectId !== model.objectId) return;
                  if (object.visible && !capturedMeshes.has(object)) object.material = occluder;
                });
              }
              return restoreScene;
            },
          },
        );
        document.body.dataset.localRepaintButton2MaskCaptureMs = (
          performance.now() - startedAt
        ).toFixed(1);
        document.body.dataset.localRepaintButton2MaskProjectionCount = '1';
        return maskUrl;
      } finally {
        material.dispose();
        occluder.dispose();
      }
    }))(captureRender); }
