import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';
import fs from 'node:fs/promises';
const require = createRequire(new URL('../apps/web/package.json', import.meta.url));
const ts = require('typescript');
const { createServer } = await import(pathToFileURL(require.resolve('vite')).href);
const file = 'apps/web/src/engine/viewport/ViewportCanvas.tsx';
const source = await fs.readFile('D:/li3d/' + file, 'utf8');
const baseline = execFileSync('git', ['show', 'HEAD:' + file], {cwd:'D:/li3d',encoding:'utf8'});
function extract(text) {
  const ast = ts.createSourceFile(file,text,ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
  const found={};
  function walk(node) {
    if (ts.isFunctionDeclaration(node) && ['createInpaintMaskCaptureMaterial','bindInpaintDepthTarget'].includes(node.name?.text)) found[node.name.text]=node.getText(ast);
    if (ts.isVariableDeclaration(node) && ts.isIdentifier(node.name)) {
      if (node.name.text==='capturePaintMask') found.callback=node.initializer.arguments[0].getText(ast);
      if (['inpaintDepthShader','INPAINT_DEPTH_EPSILON','PROJECTION_PAINT_MAX_SIZE'].includes(node.name.text)) found[node.name.text]='const '+node.getText(ast)+';';
    }
    ts.forEachChild(node,walk);
  } walk(ast); return found;
}
const now=extract(source), old=extract(baseline);
const gitSource=file=>execFileSync('git',['show','HEAD:'+file],{cwd:'D:/li3d',encoding:'utf8'});
await fs.writeFile('D:/li3d/.codex-tmp/render-before.ts',gitSource('apps/web/src/engine/capture/renderTargetUtils.ts').replace("'./gpuReadbackPngWorker'","'./png-before-client'").replace("'@/engine/bake/gpuReadbackStripes'","'./readback-before'"));
await fs.writeFile('D:/li3d/.codex-tmp/png-before-client.ts',gitSource('apps/web/src/engine/capture/gpuReadbackPngWorker.ts').replace("'../../workers/encodeGpuReadbackPng.worker.ts'","'./png-before.worker.ts'"));
const colorFile='apps/web/src/engine/capture/captureCurrentView.ts';
function colorFunctions(text) {
 const ast=ts.createSourceFile(colorFile,text,ts.ScriptTarget.Latest,true);
 return ast.statements.filter(n=>ts.isFunctionDeclaration(n)&&['captureClayTarget','captureFlatTarget','createFlatTargetCaptureMaterial','prepareFlatTargetCapture'].includes(n.name?.text)).map(n=>n.getText(ast)).join('\n');
}
await fs.writeFile('D:/li3d/.codex-tmp/color-check-source.ts', `import * as THREE from 'three';
import { renderSceneToPngUrl, applyTargetOnlyMaterial, isCaptureTargetMesh } from '/src/engine/capture/renderTargetUtils.ts';
import { renderSceneToPngUrl as renderBefore } from './render-before';
import { createClayModelMaterial } from '/src/engine/materials/clayModelMaterial.ts';
import { waitForBrowserPaint as waitForViewportFrame } from '/src/utils/browserScheduling.ts';
const waitForResidentUvPresentation=async()=>{};
export function colorsOld(){const renderSceneToPngUrl=renderBefore;${colorFunctions(execFileSync('git',['show','HEAD:'+colorFile],{cwd:'D:/li3d',encoding:'utf8'}))};return {clay:captureClayTarget,flat:captureFlatTarget};}
export function colorsNew(){${colorFunctions(await fs.readFile('D:/li3d/'+colorFile,'utf8'))};return {clay:captureClayTarget,flat:captureFlatTarget};}
`);
const scope='getTargetModel,layerRef,isPerformanceInstrumentationEnabled,maskHasContentRef,currentProjectionHasContentRef,currentProjectionOperationRef,archiveCurrentInpaintProjection,gl,scene,camera';
await fs.writeFile('D:/li3d/.codex-tmp/mask-check-source.ts', `import * as THREE from 'three';
import { renderSceneToPngUrl, applyTargetOnlyMaterial, cloneCameraForCaptureAspect } from '/src/engine/capture/renderTargetUtils.ts';
import { renderSceneToPngUrl as renderBefore } from './render-before';
import { waitForBrowserPaint } from '/src/utils/browserScheduling.ts';
${Object.entries(now).filter(([key])=>key!=='callback').map(([,value])=>value).join('\n')}
export function makeCapture(mode, scope) { const {${scope}}=scope; const captureRender=mode==='old'?renderBefore:renderSceneToPngUrl; return ((renderSceneToPngUrl)=>mode==='old' ? (${old.callback}) : (${now.callback}))(captureRender); }
`);
process.env.LI3D_DEBUG_BUILD='false';
const server=await createServer({configFile:'D:/li3d/apps/web/vite.config.ts',root:'D:/li3d/apps/web',optimizeDeps:{entries:['index.html']},resolve:{dedupe:['three']},server:{host:'127.0.0.1',port:4529,strictPort:true},plugins:[{name:'mask-check',configureServer(server){server.middlewares.use(async(req,res,next)=>{
  if(req.url==='/__mask-check'){res.setHeader('content-type','text/html; charset=utf-8');res.end(await server.transformIndexHtml(req.url,`<!doctype html><html><head><meta charset="utf-8"><title>蒙版捕获 A/B 验证</title><style>body{margin:0;background:#12181f;color:#dbe6ef;font:14px system-ui}header{position:absolute;top:12px;left:16px;z-index:2}button{padding:10px;margin-right:8px}pre{max-height:65vh;overflow:auto;background:#12181fcc;max-width:1000px}canvas{display:block;width:100vw;height:100vh}</style></head><body><header><button id="full">进入全屏</button><button id="run">运行前后对照</button><pre id="result">加载中</pre></header><script type="module" src="/@fs/D:/li3d/.codex-tmp/mask-check-browser.mjs"></script></body></html>`));}
  else if(req.url==='/__bicycle.glb'){res.setHeader('content-type','model/gltf-binary');res.end(await fs.readFile('D:/li3d/temp/li3dTests/Bicycle/Bicycle.glb'));}
  else if(req.url.startsWith('/__artifact/')&&req.method==='POST'){
    const name=req.url.slice('/__artifact/'.length);if(!/^[a-z0-9_.-]+$/.test(name)){res.statusCode=400;res.end();return;}
    const dir='D:/li3d/output/texture-optimization-20260929';await fs.mkdir(dir,{recursive:true});const chunks=[];for await(const part of req)chunks.push(part);await fs.writeFile(dir+'/'+name,Buffer.concat(chunks));res.end('saved');
  }
  else if(req.url==='/__evidence'&&req.method==='POST'){let data='';for await(const part of req)data+=part;await fs.writeFile('D:/li3d/.codex-tmp/mask-check-results.json',data);res.end('saved');}
  else next();
});}}]});
await server.listen();console.log('http://127.0.0.1:4529/__mask-check');
