import * as THREE from 'three';
import {GLTFLoader} from 'three/examples/jsm/loaders/GLTFLoader.js';
import {serializeCamera} from '/src/engine/projection/ProjectionCamera.ts';
import {revokeRegisteredObjectUrl} from '/src/utils/blobUrlRegistry.ts';
import {run as a} from './runtime-a.ts';
import {run as b} from './runtime-b.ts';
import {run as c} from './runtime-c.ts';
const out=document.querySelector('#result');document.querySelector('#full').onclick=()=>document.documentElement.requestFullscreen();
const gl=new THREE.WebGLRenderer({antialias:true});gl.setPixelRatio(1);gl.setSize(innerWidth,innerHeight);document.body.append(gl.domElement);
const scene=new THREE.Scene();scene.background=new THREE.Color('#19232d');const camera=new THREE.PerspectiveCamera(40,innerWidth/innerHeight,.1,30);camera.position.set(3,1.5,5);camera.lookAt(0,0,0);scene.add(new THREE.HemisphereLight(0xffffff,0x555555,3));
const model=(await new GLTFLoader().loadAsync('/__bicycle.glb')).scene;const box=new THREE.Box3().setFromObject(model),size=box.getSize(new THREE.Vector3());model.position.sub(box.getCenter(new THREE.Vector3()));const parent=new THREE.Group();parent.add(model);parent.scale.setScalar(3/Math.max(size.x,size.y,size.z));scene.add(parent);scene.updateMatrixWorld(true);
const stress=new THREE.Group();for(let i=0;i<6;i++){const clone=parent.clone(true);clone.position.set(i*.015,i*.008,i*.02);stress.add(clone);}stress.updateMatrixWorld(true);
let active=false,frames=[],input=[],draws=[],viewFrames=0,last=performance.now(),rotation=0;
const render=gl.render.bind(gl);gl.render=(s,cam)=>{const start=performance.now();render(s,cam);if(active&&s!==scene)draws.push(performance.now()-start);};
addEventListener('pointermove',e=>{if(active){input.push(performance.now()-e.timeStamp);rotation=e.clientX/innerWidth*.2;}});
function loop(t){if(active){frames.push(t-last);viewFrames++;}last=t;camera.position.x=3+rotation;camera.lookAt(0,0,0);gl.render(scene,camera);requestAnimationFrame(loop);}requestAnimationFrame(loop);
addEventListener('resize',()=>{gl.setSize(innerWidth,innerHeight);camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();});
const pct=(v,p)=>v.length?[...v].sort((a,b)=>a-b)[Math.min(v.length-1,Math.floor(v.length*p))]:null;
async function pixels(url){const image=await createImageBitmap(await(await fetch(url)).blob());const canvas=new OffscreenCanvas(image.width,image.height),ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.drawImage(image,0,0);image.close();return ctx.getImageData(0,0,canvas.width,canvas.height).data;}
const save=(name,body)=>fetch('/__artifact/'+name,{method:'POST',body});
out.textContent='就绪 · A=256px 分块 / B=整张保留 pass 间等待 / C=整张去掉 pass 间绘制帧等待';
document.querySelector('#run').onclick=async()=>{
 const rows=[];try{
  if(!document.fullscreenElement||document.visibilityState!=='visible')throw Error('需要可见全屏');document.querySelector('#run').disabled=true;
  const viewport=[innerWidth,innerHeight];const frozen=camera.clone();frozen.aspect=1;frozen.updateProjectionMatrix();frozen.updateMatrixWorld(true);const snapshot=serializeCamera(frozen,1,new THREE.Vector3());
  const scenarios=[{name:'bike512-depth',size:512,normal:false,group:parent},{name:'bike1024-depth',size:1024,normal:false,group:parent},{name:'bike1024-pair',size:1024,normal:true,group:parent},{name:'bike2048-pair',size:2048,normal:true,group:parent},{name:'stress1024-pair',size:1024,normal:true,group:stress}];
  for(const scenario of scenarios){if(location.hash&&!scenario.name.includes(location.hash.slice(1)))continue;let goldenDepth,goldenNormal;
   for(const mode of ['a','b','c','c','b','a','b','a','c','a','c','b']){
    if(!document.fullscreenElement||document.visibilityState!=='visible'||viewport[0]!==innerWidth||viewport[1]!==innerHeight)throw Error('显示状态改变，停止采样');
    out.textContent=`${scenario.name} / ${mode.toUpperCase()} · ${rows.length} 个样本`;await new Promise(requestAnimationFrame);frames=[];input=[];draws=[];viewFrames=0;active=true;
    let gates=0;const start=performance.now();const result=await({a,b,c}[mode])({renderer:gl,group:scenario.group,camera:snapshot,width:scenario.size,height:scenario.size,includeNormal:scenario.normal,waitForViewportIdle:async()=>{gates++;}});const ms=performance.now()-start;active=false;
    const row={scenario:scenario.name,mode,ms,gates,draws:draws.length,maxSubmitMs:Math.max(...draws),frameP95:pct(frames,.95),frameMax:Math.max(...frames),inputP95:pct(input,.95),inputCount:input.length,viewFrames,timing:JSON.parse(document.body.dataset.runtimeProjectionVisibilityLastTiming)};
    const depth=await pixels(result.depthUrl),normal=result.normalUrl?await pixels(result.normalUrl):undefined;
    if(!goldenDepth){goldenDepth=depth;goldenNormal=normal;}
    let depthDifferences=0,normalDifferences=0,covered=0;for(let i=0;i<depth.length;i++){if(depth[i]!==goldenDepth[i])depthDifferences++;if(i%4===0&&(depth[i]!==255||depth[i+1]!==255||depth[i+2]!==255))covered++;}if(normal)for(let i=0;i<normal.length;i++)if(normal[i]!==goldenNormal[i])normalDifferences++;
    const first=!rows.some(r=>r.scenario===scenario.name&&r.mode===mode);
    if(first){await save('runtime-'+scenario.name+'-'+mode+'-depth.png',await(await fetch(result.depthUrl)).blob());if(result.normalUrl)await save('runtime-'+scenario.name+'-'+mode+'-normal.png',await(await fetch(result.normalUrl)).blob());}
    revokeRegisteredObjectUrl(result.depthUrl);revokeRegisteredObjectUrl(result.normalUrl);rows.push({...row,depthDifferences,normalDifferences,covered});
    if(depthDifferences||normalDifferences||!covered)throw Error('像素不一致或空图');
   }
   await save(location.hash?'runtime-confirm.json':'runtime-results.json',JSON.stringify({viewport,rows,complete:false},null,2));
  }
  const report={viewport,rows,complete:true};await save(location.hash?'runtime-confirm.json':'runtime-results.json',JSON.stringify(report,null,2));out.textContent='PASS\n'+JSON.stringify(report,null,2);
 }catch(e){active=false;out.textContent='FAIL '+e.stack;await save('runtime-results.json',JSON.stringify({rows,complete:false,error:String(e)},null,2));}finally{document.querySelector('#run').disabled=false;}
};
